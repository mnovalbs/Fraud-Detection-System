
      </div>
    <script>
      function base_url(str){
        return "<?php echo base_url(); ?>"+str;
      }
    </script>
    <script src='<?php echo base_url('assets/js/jquery.min.js'); ?>'></script>
    <script src='<?php echo base_url('assets/js/script.js?ver='.date("YmdHis")); ?>'></script>
  </body>
</html>
