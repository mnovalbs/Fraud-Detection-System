<!DOCTYPE html>
<html lang='id'>
  <head>
    <meta charset="utf-8">
    <title>Tiket Pesawat</title>
    <link href='<?php echo base_url('assets/css/bootstrap.min.css'); ?>' rel='stylesheet'/>
    <link href='<?php echo base_url('assets/css/style.css?ver='.date("YmdHis")); ?>' rel='stylesheet'/>
  </head>
  <body>
    <div class='container'>
